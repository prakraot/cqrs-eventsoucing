package com.wf.obaas.entity;

import java.time.LocalDateTime;

public class OnbRequest {
	private Integer id;
	private LocalDateTime createdDate;
	private Requestor requestor;
	private Client client;

	enum status {
		CREATED, CANCELLED, IN_PROGRESS, COMPLETED
	};

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public Requestor getRequestor() {
		return requestor;
	}

	public void setRequestor(Requestor requestor) {
		this.requestor = requestor;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

}
