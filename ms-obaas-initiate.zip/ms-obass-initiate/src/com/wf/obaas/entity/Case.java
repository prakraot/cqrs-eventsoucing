package com.wf.obaas.entity;

public class Case {
	Integer id;
}
