package com.wf.obaas.entity;

public class Client {
	
	Integer id;
	String leName;
	String Adrress;
	String contact;
	String email;
	
	public Client(Integer id, String leName, String adrress, String contact, String email) {
		super();
		this.id = id;
		this.leName = leName;
		Adrress = adrress;
		this.contact = contact;
		this.email = email;
	}
	

}
