package com.wf.obaas.entity;

public class Requestor {

	String id;
	String firstName;
	String LastName;

	public Requestor(String id, String firstName, String lastName) {
		super();
		this.id = id;
		this.firstName = firstName;
		LastName = lastName;
	}

}
