package com.wf.obaas.model.view;

public class OnbRequestDTO {

}
