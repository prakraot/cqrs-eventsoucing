package com.wf.obaas.query;

public interface Query {
	enum status {
		SUCCESSFUL,FAILED
	};
	status execute();
}
