package com.wf.obaas.query.handler;

import org.springframework.beans.factory.annotation.Autowired;
import com.wf.obaas.model.view.OnbRequestDTO;
import com.wf.obaas.repository.OnbRequestRepository;

public class QueryHandler {
	@Autowired
	private OnbRequestRepository repository;
	
	public OnbRequestDTO getRequestById(){
		repository.findById();
		}
		  
		public List<OnbRequestDTO> getRequestsByUser(){
			repository.findByName();
		}
		
		public List<OnbRequestDTO> getAllRequests(){
			repository.findAll();
		}

}
