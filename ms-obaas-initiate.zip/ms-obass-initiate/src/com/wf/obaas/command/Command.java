package com.wf.obaas.command;

public interface Command {
	enum status {
		SUCCESSFUL,FAILED
	};

	status execute();
}
