package com.wf.obaas.command.handler;

import com.wf.obaas.command.CancelRequestCommand;
import com.wf.obaas.command.Command;
import com.wf.obaas.command.CreateRequestCommand;
import com.wf.obaas.command.UpdateRequestCommand;
import com.wf.obaas.event.RequestCanceledEvent;
import com.wf.obaas.event.RequestCreatedEvent;
import com.wf.obaas.event.RequestUpdateEvent;
import com.wf.obaas.event.handler.EventHandler;

public class CommandHandler {
	public void handleCommand(Command command) {

		if (command instanceof CreateRequestCommand) {
			command.execute();
			new EventHandler().handleEvent(new RequestCreatedEvent());
		} else if (command instanceof UpdateRequestCommand) {
			command.execute();
			new EventHandler().handleEvent(new RequestUpdateEvent());
		} else if (command instanceof CancelRequestCommand) {
			command.execute();
			new EventHandler().handleEvent(new RequestCanceledEvent());
		}
	}
}
