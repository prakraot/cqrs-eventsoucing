package com.wf.obaas.command;

import org.springframework.beans.factory.annotation.Autowired;
import com.wf.obaas.command.Command.status;
import com.wf.obaas.repository.OnbRequestRepository;

public class CreateRequestCommand implements Command {
	@Autowired
	private OnbRequestRepository repository;

	@Override
	public Command.status execute() {
		// TODO Auto-generated method stub
		repository.save();
		return status.SUCCESSFUL;
	}

}
