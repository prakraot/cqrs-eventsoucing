package com.wf.obaas.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.wf.obaas.entity.*;

public class OnbRequestRepository extends JpaRepository<OnbRequest, Long>{{

}
