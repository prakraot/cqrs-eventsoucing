package com.wf.obaas.event;

public class RequestUpdateEvent extends Event {

}
