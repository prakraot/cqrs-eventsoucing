package com.wf.obaas.event.handler;

import com.wf.obaas.event.Event;

public class EventHandler {
	public void handleEvent(Event event){
	     save(event);
		 publish(event);
}

	private void publish(Event event) {
		// save to event store
		
	}

	private void save(Event event) {
		// publish to Kakfa
		
	}
}
