package com.wf.obaas.event;

import java.time.LocalDateTime;

public class Event {
	private Integer id;
	private LocalDateTime createdDateTime;
	
}
