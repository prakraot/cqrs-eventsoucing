package com.wf.obaas.event;

public class RequestCanceledEvent extends Event {

}
