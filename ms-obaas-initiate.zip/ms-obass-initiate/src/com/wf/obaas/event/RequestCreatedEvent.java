package com.wf.obaas.event;

public class RequestCreatedEvent extends Event {

}
